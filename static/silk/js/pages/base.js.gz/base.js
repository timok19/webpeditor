$(document).ready(function () {
    configureSpanFontColors($('#num-joins-div').find('.numeric'), 3, 5);
    configureSpanFontColors($('#time-taken-div').find('.numeric'), 200, 500);
    configureSpanFontColors($('#num-queries-div').find('.numeric'), 10, 500);
});
